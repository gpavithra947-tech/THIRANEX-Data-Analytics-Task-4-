
import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("sales_data.csv")

# Show original data
print("Original Data")
print(data)

# Fill missing values
data["Amount"].fillna(0, inplace=True)

# Remove duplicates
data.drop_duplicates(inplace=True)

# Convert city names to uppercase
data["City"] = data["City"].str.upper()

# Show cleaned data
print("\nCleaned Data")
print(data)

# Total sales report
total_sales = data["Amount"].sum()

print("\nTotal Sales =", total_sales)

# Product-wise sales report
report = data.groupby("Product")["Amount"].sum()

print("\nProduct Wise Report")
print(report)

# Create chart
data.groupby("City")["Amount"].sum().plot(kind="bar")

plt.title("Sales by City")
plt.xlabel("City")
plt.ylabel("Sales Amount")

plt.show()

# Export cleaned report
data.to_excel("cleaned_report.xlsx", index=False)

print("\nReport Generated Successfully")
